package com.textclockexample.n01103934.textclock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;     // to use Bundles
import android.view.View;      // to use Views
import android.widget.Button; // to use Buttons
import android.widget.TextClock; // to use TextClocks
import android.widget.TextView; // to use TextViews

public class MainActivity extends AppCompatActivity {

    private TextClock textClock1; // A global variable to define my TextClock topic.
    private TextView textView1;  // A first global view variable to show and display TextClock to the screen.
    private TextView textView2; // A second global view variable to show the cureent time as text to the screen
    private Button button; // A button variable used below to show current time when a user clicks on it.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // First Activity called from MainActivity.
        setContentView(R.layout.activity_main); // Find and set the layout based on activity_main layout file.
        textClock1 = (TextClock) findViewById(R.id.textClock1); // Find the text clock resource that already is declared in layout file.
        textView1 = (TextView) findViewById(R.id.textView1); // Find the first text view resource that already is declared in layout file.
        textView2 = (TextView) findViewById(R.id.textView2); // Find the second text view resource that already is declared in layout file.
        button = (Button) findViewById(R.id.button1);       // Find the button resource that is declared in layout file.

        button.setOnClickListener(new View.OnClickListener() // An OnClickListener to implement an event/activity to display current time when a user clicks on it.
        {
            @Override
            public void onClick(View v) {
                // Creates and sets a view to show the current time in hh/mm/ss using TextClock.
                textView1.setText("Time: " + textClock1.getText()); // When the user clicks on the get time button then the current time is displayed on the screen.
                textView2.setText("Time: " + textClock1.getFormat12Hour()); // When the user clicks on the get time button then the current time in text are displayed as hh:mm:ss:a.
                                                                            // The text format of the current time displayed is returned in 12 hour mode.
            }
        });
    }
}


